/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package flight.booking.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class FlightBookingSystem {
    
    
    public static void main(String[] args) throws FileNotFoundException {
        
                // Create a scanner object to read from the keyboard  

        Scanner keyboard=new Scanner(System.in);
        
        ArrayList<Receipt>ob=new ArrayList<>();
        //arraylist to holds the class`s Receipt
        System.out.println("\t\tFlight booking system\n");
        
                // The do loop allows the menu to be displayed first 

        do {
            String name;
            System.out.println("=============================================");
            System.out.println("1. add booking ");
            System.out.println("2. search for user ");
            System.out.println("3. exit");
            System.out.println("=============================================");
            int num=keyboard.nextInt();
            
            switch (num){
                case 1:
                    ob.add(new Receipt());
                    ob.get(ob.size()-1).setCustomer();
                    ob.get(ob.size()-1).setFlight();
                    ob.get(ob.size()-1).writeTheBookingInFile();
                    System.out.println(ob.get(ob.size()-1).toString());
                    break;
                case 2:
                    System.out.println("Enter name : ");
                     name=keyboard.nextLine();
                    name=keyboard.nextLine();
                    search(name);
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Wrong try again ");
            }
            if(num==3)
                break;
        }while (true);
        
    }
    public static void search(String name) throws FileNotFoundException {
        File file = new File(name + ".txt");
        if (file.exists()) {
            System.out.println("=============================================");
            
                    // Create a scanner object to read from the keyboard  
            Scanner keyboard = new Scanner(file);
            while (keyboard.hasNext()) {
                System.out.println(keyboard.nextLine());
            }
            System.out.println("=============================================");
            keyboard.close();
        } else
            System.out.println("can't find this customer ");
    }
   
}
