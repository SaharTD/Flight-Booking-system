/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flight.booking.system;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
       
        
public class Receipt {
    
    
    private static int Seat_number = 1;
    private Customer customer;
    private Flight flight;
    private int seat = Seat_number;

    public Receipt() {
        Seat_number += 1; 
    }
    

    
    public Receipt(Customer customer, Flight flight, int seat) {
        this.customer = customer;
        this.flight = flight;
        this.seat = seat;
        Seat_number += 1;
    }

    public Customer getCustomer() {
        return customer;
    }

    public int getSeat() {
        return seat;
    }

    public void setSeat(int seat) {
        this.seat = seat;
    }

    public void setCustomer() {
        Scanner in = new Scanner(System.in);
        String name;
        
        boolean check = false;
        do {
            System.out.print("Enter your name : ");
            name = in.nextLine();
            for (int i = 0; i < name.length(); i++) 
            {
                if (Character.isAlphabetic(name.charAt(i))) {
                    check = false;
                } else {
                    check = true;
                }

            }
        } while (check);
        
        
        int national_id;
        do {
            System.out.print("Enter your national id : ");
            national_id = in.nextInt();
            if (national_id > 0)
                break;
        } while (true);
        
        String gander;
        do {
            System.out.print("Enter your gander ( male or female) : ");
            gander = in.next();
            if (gander.equalsIgnoreCase("male") || gander.equalsIgnoreCase("female"))
                break;
        } while (true);
        
        
        
        System.out.print("Enter your email : ");
        String email = in.next();
        Customer customer1 = new Customer(national_id, name, gander, email);
        System.out.println("_____________");
        this.customer = customer1;
    }

    public Flight getFlight() {
        return flight;
    }

    public void setFlight() {
        
        
        Scanner in = new Scanner(System.in);
        int num = 0;
        String destination = " ";
        
        do {
            System.out.println("chose destination ");
            System.out.println("\t\tdestination\n" +
                    "1. From Jeddah to Riyadh\n" +
                    "2. From Riyadh to Jeddah \n" +
                    "3. From Riyadh to Madina\n" +
                    "4. From Madina to Riyadh\n" +
                    "5. From Jeddah to Madina\n" +
                    "6. From Madina to Jeddah \n");
            num = in.nextInt();
            
            switch (num) {
                case 1:
                    destination = "From Jeddah to Riyadh";
                    break;
                case 2:
                    destination = "From Riyadh to Jeddah";
                    break;
                case 3:
                    destination = "From Riyadh to Madina";
                    break;
                case 4:
                    destination = "From Madina to Riyadh";
                    break;
                case 5:
                    destination = "From Jeddah to Madina";
                    break;
                case 6:
                    destination = "From Madina to Jeddah";
                    break;
                default:
                    System.out.println("Wrong try again");
            }
        } while (num <= 0 || num > 6);
        
        
        double price = 0;
        String seat_type = " ";
        
        do {
            System.out.println("chose seat type");
            System.out.println("1. First class\n" +
                    "2. Business \n" +
                    "3. Economy");
            num = in.nextInt();
            
            switch (num) {
                case 1:
                    seat_type = "first class";
                    if (destination.equalsIgnoreCase("From Jeddah to Riyadh") ||
                            destination.equalsIgnoreCase("From Riyadh to Jeddah"))
                        price = 700;
                    else if (destination.equalsIgnoreCase("From Riyadh to Madina") ||
                            destination.equalsIgnoreCase("From Madina to Riyadh"))
                        price = 900;
                    else if (destination.equalsIgnoreCase("From Jeddah to Madina") ||
                            destination.equalsIgnoreCase("From Madina to Jeddah"))
                        price = 850;
                    break;
                case 2:
                    seat_type = "first class";
                    if (destination.equalsIgnoreCase("From Jeddah to Riyadh") ||
                            destination.equalsIgnoreCase("From Riyadh to Jeddah"))
                        price = 500;
                    else if (destination.equalsIgnoreCase("From Riyadh to Madina") ||
                            destination.equalsIgnoreCase("From Madina to Riyadh"))
                        price = 700;
                    else if (destination.equalsIgnoreCase("From Jeddah to Madina") ||
                            destination.equalsIgnoreCase("From Madina to Jeddah"))
                        price = 650;
                    break;
                case 3:
                    seat_type = "economy";
                    if (destination.equalsIgnoreCase("From Jeddah to Riyadh") ||
                            destination.equalsIgnoreCase("From Riyadh to Jeddah"))
                        price = 300;
                    else if (destination.equalsIgnoreCase("From Riyadh to Madina") ||
                            destination.equalsIgnoreCase("From Madina to Riyadh"))
                        price = 500;
                    else if (destination.equalsIgnoreCase("From Jeddah to Madina") ||
                            destination.equalsIgnoreCase("From Madina to Jeddah"))
                        price = 450;
                    break;
                default:
                    System.out.println("Wrong try again");
            }
        } while (num < 1 || num > 3);
        
        
        String date = " ";
        do {
            System.out.println("Chose a day ");
            System.out.println("1. Monday\n" +
                    "2. Tuesday\n" +
                    "3. Wednesday\n" +
                    "4. Thursday\n" +
                    "5. Friday\n" +
                    "6. Saturday\n" +
                    "7. Sunday");
            num = in.nextInt();
            switch (num) {
                case 1:
                    date = "Monday";
                    break;
                case 2:
                    date = "Tuesday";
                    break;
                case 3:
                    date = "Wednesday";
                    break;
                case 4:
                    date = "Thursday";
                    break;
                case 5:
                    date = "Friday";
                    break;
                case 6:
                    date = "Saturday";
                    break;
                case 7:
                    date = "Sunday";
                    break;
                default:
                    System.out.println("Wrong try again");
            }
        } while (num < 0 || num > 7);
        
        
        System.out.println("_____________");
        Flight flight1 = new Flight(price, destination, seat_type, date);
        this.flight = flight1;
    }

    public void writeTheBookingInFile() throws FileNotFoundException {
        PrintWriter printWriter = new PrintWriter(customer.getCustomer_name() + ".txt");
        printWriter.println(toString());
        printWriter.close();
    }

     /** 
 The toString method 
 @return A String object containing the Receipt ,
 * customer,flight and seat number.
 */ 

    public String toString() {
        return "=============================================\n" +
                "\t\t\tReceipt\n" +
                "\t\tcustomer\n" + customer.toString() +
                "\t\tflight\n" + flight.toString() +
                " seat number # " + seat+"\n" +
                "=============================================";
    }
}


