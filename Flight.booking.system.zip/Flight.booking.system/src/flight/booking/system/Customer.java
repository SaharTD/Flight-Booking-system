/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flight.booking.system;

/**
 *
 * @author USER
 */
public class Customer {
    private int customer_national_id;
    private String customer_name;
    private String customer_gander;
    private String email;

    public Customer() {
    }
    public Customer(int customer_national_id, String customer_name, String customer_gander, String email) {
        this.customer_national_id = customer_national_id;
        this.customer_name = customer_name;
        this.customer_gander = customer_gander;
        this.email = email;
    }

    public int getCustomer_national_id() {
        return customer_national_id;
    }

    public void setCustomer_national_id(int customer_national_id) {
        this.customer_national_id = customer_national_id;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getCustomer_gander() {
        return customer_gander;
    }

    public void setCustomer_gander(String customer_gander) {
        this.customer_gander = customer_gander;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    
    /** 
 The toString method 
 @return A String object containing the customer national id ,
 * customer name,customer gander and email.
 */ 
    
    public String toString() {
        return "customer national id= " + customer_national_id +
                "\ncustomer name= " + customer_name +
                "\ncustomer gander= " + customer_gander +
                "\n email= " + email +'\n';
    }
}