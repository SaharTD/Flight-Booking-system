/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flight.booking.system;

/**
 *
 * @author USER
 */
public class Flight {
    private double price;
    private String destination;
    private String seat_type;
    private String day;

    public Flight() {
    }

    public Flight(double price, String destination, String seat_type, String day) {
        this.price = price;
        this.destination = destination;
        this.seat_type = seat_type;
        this.day = day;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getSeat_type() {
        return seat_type;
    }

    public void setSeat_type(String seat_type) {
        this.seat_type = seat_type;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }
 /** 
 The toString method 
 @return A String object containing the  destination,
 * seat typ,day and price.
 */ 

    public String toString() {
        return "destination= " + destination +
                "\nseat type= " + seat_type +
                "\nday= " + day +
                "\nprice= " + price+" SR\n" ;
    }
}